---
name: Bug Report — Broken Workflow
about: Report a workflow that no longer works correctly
title: "Bug: [workflow filename] — [brief description]"
labels: bug
assignees: ''
---

## Which workflow file is broken?

<!-- e.g. workflows/ai-automation/ai-content-factory.json -->

## Your n8n version

<!-- Found in Settings → About -->

## Error message from the execution log

```
Paste the exact error here
```

## Steps to reproduce

1.
2.
3.

## What you already tried

<!-- What did you change or check before opening this issue? -->

## Additional context

<!-- API changes? n8n update? Credential issue? Anything else relevant. -->
